﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WpfApplication.ClassData
{
    internal class ClassFrameNavigation
    {
        public static Frame frmBodyNav { get; set; }
    }
}
